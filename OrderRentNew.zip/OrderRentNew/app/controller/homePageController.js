app.controller('homePageController',function($scope,$http){
    var jsonDataPath = "json/jsonData.json";
	$scope.header1 = "Rent the house";
	$scope.header2 = "The Below is been tried out with JSON";
    
    
  	$http.get(jsonDataPath).then(function(results){
	    $scope.displayContentJSON = results.data;
	});

	var _latitude = 13.067439;
    var _longitude = 80.23761;
    var jsonPath = 'json/items.json';

    // Load JSON data and create Google Maps

    $.getJSON(jsonPath)
    	.done(function(json) {
            createHomepageGoogleMap(_latitude,_longitude,json);
        })
        .fail(function( jqxhr, textStatus, error ) {
            console.log(error);
        });
});