var app = angular.module('orderRentApp',['ui.router','ui.bootstrap']);

app.config(['$stateProvider', '$urlRouterProvider', '$qProvider' ,function($stateProvider,$urlRouterProvider,$qProvider){
      $qProvider.errorOnUnhandledRejections(false);
      $urlRouterProvider.otherwise("/home");
      $stateProvider
      .state('home', {
            url: "/home",
            templateUrl: 'app/view/search.html',
            controller: 'searchController'
      })
      .state('locationOnMap', {
            url: "/locationOnMap",
            templateUrl: 'app/view/locationOnMap.html',
            controller: 'homePageController'
      })
}]);