// app.js
var app = angular.module('orderRent', ['ui.router','ui.bootstrap']);

app.config(['$stateProvider', '$urlRouterProvider', '$qProvider',function($stateProvider, $urlRouterProvider,$qProvider) {
    
    $qProvider.errorOnUnhandledRejections(false);

    $urlRouterProvider.otherwise('/home');
    
    $stateProvider
        
        .state('home', {
            url: '/home',
            templateUrl: 'views/search.html',
            controller : 'searchController'
        })

        // nested list with custom controller
        .state('locationOnMap', {
            url: '/locationOnMap',
            templateUrl: 'views/locationOnMap.html',
            controller: 'homePageController'
        })
        
        // ABOUT PAGE AND MULTIPLE NAMED VIEWS =================================
        // .state('about', {
        //     // we'll get to this in a bit       
        // });
        
}]);