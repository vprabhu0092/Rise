var app = angular.module('orderRent', []);

app.controller('homePageController', function ($scope){
    
    var jsonData1 = "assets/json/jsonData.json";
	$scope.header1 = "Rent the house";
	$scope.header2 = "The Below is been tried out with JSON";
    
    $scope.displayContentJSON = jsonData1;
    
  
//	$scope.displayContentJSON = [
//		{
//			"price" : "$25.000",
//			"link"	: {
//				"html" : "assets/pages/items/1_e.html",
//				"img"  : "assets/img/items/1.jpg"
//			},
//			"address1" : "2151 Mulberry Avenue",
//			"address2" : "63 Birch Street",
//			"roomDetails"  : {
//				"bathrooms" : 1,
//				"bedrooms"	: 3,
//				"Area"		: "1200 Sq.ft",
//				"garage"	: 1
//			}
//		},
//		{
//			"price" : "$48.000",
//			"link"	: {
//				"html" : "assets/pages/items/2_e.html",
//				"img"  : "assets/img/items/2.jpg"
//			},
//			"address1" : "3N Linlcon Street",
//			"address2" : "DC",
//			"roomDetails"  : {
//				"bathrooms" : 2,
//				"bedrooms"	: 7,
//				"Area"		: "1200 Sq.ft",
//				"garage"	: 2
//			}
//		},
//		{
//			"price" : "$150.000",
//			"link"	: {
//				"html" : "assets/pages/items/8_e.html",
//				"img"  : "assets/img/items/8.jpg"
//			},
//			"address1" : "home3",
//			"address2" : "DC",
//			"roomDetails"  : {
//				"bathrooms" : 2,
//				"bedrooms"	: 7,
//				"Area"		: "1200 Sq.ft",
//				"garage"	: 2
//			}
//		},
//		{
//			"price" : "$200.000",
//			"link"	: {
//				"html" : "assets/pages/items/8_e.html",
//				"img"  : "assets/img/items/8.jpg"
//			},
//			"address1" : "home3",
//			"address2" : "DC",
//			"roomDetails"  : {
//				"bathrooms" : 2,
//				"bedrooms"	: 7,
//				"Area"		: "1200 Sq.ft",
//				"garage"	: 2
//			}
//		}
//	];
});