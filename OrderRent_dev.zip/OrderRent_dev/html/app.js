// app.js
var app = angular.module('orderRent', ['ui.router']);

app.config(function($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise('/home');
    
    $stateProvider
        
        .state('home', {
            url: '/home',
            templateUrl: 'search.html',
            controller : 'searchController'
        })

        // nested list with custom controller
        .state('locationOnMap', {
            url: '/locationOnMap',
            templateUrl: 'locationOnMap.html',
            controller: 'homePageController'
        })
        
        // ABOUT PAGE AND MULTIPLE NAMED VIEWS =================================
        // .state('about', {
        //     // we'll get to this in a bit       
        // });
        
});