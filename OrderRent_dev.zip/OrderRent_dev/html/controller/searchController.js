// var app = angular.module('orderRent', []);

app.controller('searchController', function ($scope,$http,$state){
    
    $scope.OnSearch = function (){
        $state.go('locationOnMap');
    };
});